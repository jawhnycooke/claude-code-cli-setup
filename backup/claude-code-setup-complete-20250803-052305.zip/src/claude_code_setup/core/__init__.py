"""Core framework for claude-code-setup CLI.

This package contains the core CLI framework components including
command registration, context management, and plugin architecture.
"""