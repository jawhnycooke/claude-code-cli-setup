

# [0.12.0](https://github.com/schuettc/claude-code-setup/compare/v0.11.0...v0.12.0) (2025-07-27)


### Features

* add hooks system for guardrails and automation ([d9ee18a](https://github.com/schuettc/claude-code-setup/commit/d9ee18a1b22bc4b0e5ccb67510af97a345d57421))
* integrate hooks into unified CLI experience ([3ba013e](https://github.com/schuettc/claude-code-setup/commit/3ba013e3989f3970d75d3fe2f140b9f81fdfab68))

# [0.11.0](https://github.com/schuettc/claude-code-setup/compare/v0.10.0...v0.11.0) (2025-07-27)

### Features

* add generate-docs template for project documentation

# [0.10.0](https://github.com/schuettc/claude-code-setup/compare/v0.4.6...v0.10.0) (2025-07-23)


### Bug Fixes

* add docs ([82a4f8e](https://github.com/schuettc/claude-code-setup/commit/82a4f8e261493aa901522fce77beeb5315d69883))
* cleanup ([96934d1](https://github.com/schuettc/claude-code-setup/commit/96934d1d4fb743790308da49c406d0ef84b86db8))
* remove non-existent labels from auto-PR workflow ([b4cc375](https://github.com/schuettc/claude-code-setup/commit/b4cc375a4f933c404e8f10b0f5285fd0c714860c))
* remove unused import in init.ts ([c110d58](https://github.com/schuettc/claude-code-setup/commit/c110d582daeea6b5d9439efc2a557ba933ab3a64))


### Features

* add generate-docs template for project documentation ([068febc](https://github.com/schuettc/claude-code-setup/commit/068febcea46452ee7c8d43c6273d52f7a8d49cf2))
* enhance user experience with interactive setup and CLI-first options ([9fc2ad7](https://github.com/schuettc/claude-code-setup/commit/9fc2ad73ba63c8a6f2bb3da2a786b283a55a1065))

# [0.9.0](https://github.com/schuettc/claude-code-setup/compare/v0.4.6...v0.9.0) (2025-07-23)


### Bug Fixes

* add docs ([82a4f8e](https://github.com/schuettc/claude-code-setup/commit/82a4f8e261493aa901522fce77beeb5315d69883))
* cleanup ([96934d1](https://github.com/schuettc/claude-code-setup/commit/96934d1d4fb743790308da49c406d0ef84b86db8))
* remove non-existent labels from auto-PR workflow ([b4cc375](https://github.com/schuettc/claude-code-setup/commit/b4cc375a4f933c404e8f10b0f5285fd0c714860c))
* remove unused import in init.ts ([c110d58](https://github.com/schuettc/claude-code-setup/commit/c110d582daeea6b5d9439efc2a557ba933ab3a64))


### Features

* add generate-docs template for project documentation ([068febc](https://github.com/schuettc/claude-code-setup/commit/068febcea46452ee7c8d43c6273d52f7a8d49cf2))
* enhance user experience with interactive setup and CLI-first options ([9fc2ad7](https://github.com/schuettc/claude-code-setup/commit/9fc2ad73ba63c8a6f2bb3da2a786b283a55a1065))

# [0.8.0](https://github.com/schuettc/claude-code-setup/compare/v0.4.6...v0.8.0) (2025-07-23)


### Bug Fixes

* add docs ([82a4f8e](https://github.com/schuettc/claude-code-setup/commit/82a4f8e261493aa901522fce77beeb5315d69883))
* cleanup ([96934d1](https://github.com/schuettc/claude-code-setup/commit/96934d1d4fb743790308da49c406d0ef84b86db8))
* remove non-existent labels from auto-PR workflow ([b4cc375](https://github.com/schuettc/claude-code-setup/commit/b4cc375a4f933c404e8f10b0f5285fd0c714860c))
* remove unused import in init.ts ([c110d58](https://github.com/schuettc/claude-code-setup/commit/c110d582daeea6b5d9439efc2a557ba933ab3a64))


### Features

* add generate-docs template for project documentation ([068febc](https://github.com/schuettc/claude-code-setup/commit/068febcea46452ee7c8d43c6273d52f7a8d49cf2))
* enhance user experience with interactive setup and CLI-first options ([9fc2ad7](https://github.com/schuettc/claude-code-setup/commit/9fc2ad73ba63c8a6f2bb3da2a786b283a55a1065))

# [0.6.0](https://github.com/schuettc/claude-code-setup/compare/v0.4.4...v0.6.0) (2025-05-21)


### Bug Fixes

* eliminate duplicate test runs in CI workflow ([9c2a265](https://github.com/schuettc/claude-code-setup/commit/9c2a2651fc709a857bf3cdf06540b1441bd81405))
* improve npm publish workflow triggers and add manual fallback ([4e8ff84](https://github.com/schuettc/claude-code-setup/commit/4e8ff84fdd259dcd2e44ad2ffc227de4ca67a391))
* remove unused import in init.ts ([c110d58](https://github.com/schuettc/claude-code-setup/commit/c110d582daeea6b5d9439efc2a557ba933ab3a64))
* update auto-PR workflow to trigger on version changes ([370e8cd](https://github.com/schuettc/claude-code-setup/commit/370e8cd83e2181974bd51f36a67cc3609f941444))


### Features

* add automatic PR creation when tests pass on develop ([f42a49b](https://github.com/schuettc/claude-code-setup/commit/f42a49b336aa73928914cab43e4a1c51c95150bd))
* enhance user experience with interactive setup and CLI-first options ([9fc2ad7](https://github.com/schuettc/claude-code-setup/commit/9fc2ad73ba63c8a6f2bb3da2a786b283a55a1065))

# [0.5.0](https://github.com/schuettc/claude-code-setup/compare/v0.4.4...v0.5.0) (2025-05-21)


### Bug Fixes

* eliminate duplicate test runs in CI workflow ([9c2a265](https://github.com/schuettc/claude-code-setup/commit/9c2a2651fc709a857bf3cdf06540b1441bd81405))
* improve npm publish workflow triggers and add manual fallback ([4e8ff84](https://github.com/schuettc/claude-code-setup/commit/4e8ff84fdd259dcd2e44ad2ffc227de4ca67a391))
* remove unused import in init.ts ([c110d58](https://github.com/schuettc/claude-code-setup/commit/c110d582daeea6b5d9439efc2a557ba933ab3a64))
* update auto-PR workflow to trigger on version changes ([370e8cd](https://github.com/schuettc/claude-code-setup/commit/370e8cd83e2181974bd51f36a67cc3609f941444))


### Features

* add automatic PR creation when tests pass on develop ([f42a49b](https://github.com/schuettc/claude-code-setup/commit/f42a49b336aa73928914cab43e4a1c51c95150bd))
* enhance user experience with interactive setup and CLI-first options ([9fc2ad7](https://github.com/schuettc/claude-code-setup/commit/9fc2ad73ba63c8a6f2bb3da2a786b283a55a1065))


## [0.4.4](https://github.com/schuettc/claude-code-setup/compare/v0.4.3...v0.4.4) (2025-05-21)


### Bug Fixes

* resolve YAML syntax errors in release workflow heredocs ([9fb65a8](https://github.com/schuettc/claude-code-setup/commit/9fb65a80d6ecad109d1d1bcda2b489c1d0045ab6))

## [0.4.3](https://github.com/schuettc/claude-code-setup/compare/v0.4.0...v0.4.3) (2025-05-21)


### Bug Fixes

* correct YAML syntax errors in release workflows ([a448e5f](https://github.com/schuettc/claude-code-setup/commit/a448e5fcadf8407b7314de1d890ef161dcc76409))
* resolve ESLint errors in command handling and UI utilities ([18c681e](https://github.com/schuettc/claude-code-setup/commit/18c681e57405595c670ccfca2fc510d95445942d))


### Features

* add automated release workflows ([179b13e](https://github.com/schuettc/claude-code-setup/commit/179b13eed1d5b05d98158b59dad7e43bb3c80d5f))

## [0.4.2](https://github.com/schuettc/claude-code-setup/compare/v0.4.0...v0.4.2) (2025-05-21)


### Bug Fixes

* correct YAML syntax errors in release workflows ([a448e5f](https://github.com/schuettc/claude-code-setup/commit/a448e5fcadf8407b7314de1d890ef161dcc76409))
* resolve ESLint errors in command handling and UI utilities ([18c681e](https://github.com/schuettc/claude-code-setup/commit/18c681e57405595c670ccfca2fc510d95445942d))


### Features

* add automated release workflows ([179b13e](https://github.com/schuettc/claude-code-setup/commit/179b13eed1d5b05d98158b59dad7e43bb3c80d5f))

## [0.4.1](https://github.com/schuettc/claude-code-setup/compare/v0.4.0...v0.4.1) (2025-05-21)


### Bug Fixes

* correct YAML syntax errors in release workflows ([a448e5f](https://github.com/schuettc/claude-code-setup/commit/a448e5fcadf8407b7314de1d890ef161dcc76409))
* resolve ESLint errors in command handling and UI utilities ([18c681e](https://github.com/schuettc/claude-code-setup/commit/18c681e57405595c670ccfca2fc510d95445942d))


### Features

* add automated release workflows ([179b13e](https://github.com/schuettc/claude-code-setup/commit/179b13eed1d5b05d98158b59dad7e43bb3c80d5f))

# Changelog

## [0.3.3] - 2025-05-20

### Fixed
- Corrected path resolution for templates and settings when used via npx/pnpm dlx
- Updated the file path logic to work with the bundled package structure
- Added Docker-based tests to validate installed package behavior

## [0.3.2] - Previous release
EOF < /dev/null