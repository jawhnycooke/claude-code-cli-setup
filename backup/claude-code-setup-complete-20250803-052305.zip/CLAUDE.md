# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Claude Code Setup is a CLI tool that helps users set up and configure Claude Code by installing command templates and settings. The tool is inspired by shadcn/ui's approach to component installation.

## Commands

### Setup
```bash
# Install dependencies
pnpm install

# Build the project
pnpm run build
```

### Development
```bash
# Watch mode for development
pnpm run dev

# Lint the code
pnpm run lint

# Format the code
pnpm run format

# Type check
pnpm run typecheck
```

### Testing
```bash
# Run unit tests
pnpm test

# Run full CLI tests (preferred - tests real package installation)
./tests/docker/run-tests.sh

# Run individual test files
pnpm vitest run tests/cli.test.ts
```

**Note:** Always use Docker testing for CLI validation instead of direct bin execution to ensure tests match real-world package installation scenarios.

## Project Structure

- `src/commands/` - CLI command implementations
- `src/templates/` - Command templates
- `src/utils/` - Utility functions
- `src/types/` - TypeScript type definitions

## Key Implementation Details

- Uses Commander.js for CLI command structure
- Implements template management similar to shadcn/ui
- Supports dry run and test directory options
- Has a hardcoded template registry in the initial version