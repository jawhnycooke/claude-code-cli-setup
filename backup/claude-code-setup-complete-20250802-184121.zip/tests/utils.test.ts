import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import fs from 'fs-extra';
import path from 'path';
import os from 'os';
import { readSettings, mergeSettings, saveSettings } from '../src/utils/settings';

// Mock fs-extra
vi.mock('fs-extra', () => ({
  default: {
    pathExists: vi.fn(),
    readJSON: vi.fn(),
    writeJSON: vi.fn(),
    ensureDir: vi.fn().mockResolvedValue(undefined),
    existsSync: vi.fn().mockReturnValue(true),
  },
}));

// Mock path
vi.mock('path', () => ({
  default: {
    join: vi.fn((...args) => args.join('/')),
    dirname: vi.fn((p) => p.split('/').slice(0, -1).join('/')),
  },
}));

describe('Settings Utils', () => {
  const tempDir = path.join(os.tmpdir(), 'claude-code-test');
  const settingsPath = path.join(tempDir, 'settings.json');

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  describe('readSettings', () => {
    it('should return null if settings file does not exist', async () => {
      vi.mocked(fs.pathExists).mockResolvedValue(false);
      
      const result = await readSettings(settingsPath);
      
      expect(result).toBeNull();
      expect(fs.pathExists).toHaveBeenCalledWith(settingsPath);
    });

    it('should read settings file if it exists', async () => {
      const mockSettings = {
        permissions: { allow: ['Bash(git:*)'] },
        theme: 'default',
      };
      
      vi.mocked(fs.pathExists).mockResolvedValue(true);
      vi.mocked(fs.readJSON).mockResolvedValue(mockSettings);
      
      const result = await readSettings(settingsPath);
      
      expect(result).toEqual(mockSettings);
      expect(fs.pathExists).toHaveBeenCalledWith(settingsPath);
      expect(fs.readJSON).toHaveBeenCalledWith(settingsPath);
    });
  });

  describe('mergeSettings', () => {
    it('should merge two settings objects correctly', async () => {
      const existing = {
        permissions: {
          allow: ['Bash(git:*)'],
          deny: [],
        },
        theme: 'default',
        ignorePatterns: ['node_modules'],
        env: { NODE_ENV: 'development' },
      };
      
      const newSettings = {
        permissions: {
          allow: ['Bash(npm:*)'],
          deny: ['Bash(rm:*)'],
        },
        theme: 'dark',
        ignorePatterns: ['dist'],
        env: { DEBUG: 'true' },
      };
      
      const result = await mergeSettings(existing, newSettings);
      
      expect(result).toEqual({
        permissions: {
          allow: ['Bash(git:*)', 'Bash(npm:*)'],
          deny: ['Bash(rm:*)'],
        },
        theme: 'dark',
        ignorePatterns: ['node_modules', 'dist'],
        env: {
          NODE_ENV: 'development',
          DEBUG: 'true',
        },
      });
    });
  });

  describe('saveSettings', () => {
    it('should save settings to the specified path', async () => {
      const settings = {
        permissions: {
          allow: ['Bash(git:*)'],
          deny: [],
        },
        theme: 'default',
      };
      
      await saveSettings(settings, settingsPath);
      
      expect(fs.ensureDir).toHaveBeenCalledWith(path.dirname(settingsPath));
      expect(fs.writeJSON).toHaveBeenCalledWith(settingsPath, settings, { spaces: 2 });
    });
  });
});