#!/bin/bash
set -e

echo "=== Testing Installed Package ==="
echo "Current directory: $(pwd)"
echo "Package installed at: $(ls -la node_modules/@schuettc/claude-code-setup/)"

echo ""
echo "=== Directory Structure ==="
find node_modules/@schuettc -type d | sort

echo ""
echo "=== Module Files ==="
echo "utils directory: $(ls -la node_modules/@schuettc/claude-code-setup/dist/utils/)"
echo "index.js location: $(realpath node_modules/@schuettc/claude-code-setup/dist/index.js)"
echo "template.js location: $(realpath node_modules/@schuettc/claude-code-setup/dist/utils/template.js)"

echo ""
echo "=== Test: Help Command ==="
echo "Running: npx @schuettc/claude-code-setup --help"
npx @schuettc/claude-code-setup --help

echo ""
echo "=== Test: List Command (Non-Interactive) ==="
echo "Running: npx @schuettc/claude-code-setup list --no-interactive"
npx @schuettc/claude-code-setup list --no-interactive

echo ""
echo "=== Test: Init Command (Quick Setup) ==="
echo "Running: npx @schuettc/claude-code-setup init --quick --test-dir ./test-dir --force"
npx @schuettc/claude-code-setup init --quick --test-dir ./test-dir --force

echo ""
echo "=== Test: Add Template Command ==="
echo "Running: npx @schuettc/claude-code-setup add template python-optimization --test-dir ./test-dir"
npx @schuettc/claude-code-setup add template python-optimization --test-dir ./test-dir

echo ""
echo "=== Test: Add Permission Command ==="
echo "Running: npx @schuettc/claude-code-setup add permission 'Bash(docker:*)' --test-dir ./test-dir"
npx @schuettc/claude-code-setup add permission 'Bash(docker:*)' --test-dir ./test-dir

echo ""
echo "=== Success: All tests passed! ==="