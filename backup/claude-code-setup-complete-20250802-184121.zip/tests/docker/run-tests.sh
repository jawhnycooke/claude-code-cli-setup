#!/bin/bash
set -e

# Move to the project root directory
cd "$(dirname "$0")/../.."

# Build the Docker image
echo "Building Docker test image..."
docker build -t claude-code-setup-test -f tests/docker/Dockerfile .

# Run the tests
echo "Running tests in Docker container..."
docker run --rm claude-code-setup-test

echo "Docker tests completed successfully!"