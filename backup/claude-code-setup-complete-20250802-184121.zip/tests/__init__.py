"""Test package for claude-code-setup."""
