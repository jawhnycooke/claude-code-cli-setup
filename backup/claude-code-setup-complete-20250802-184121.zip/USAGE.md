# Claude Code Setup - Usage Guide

This document provides detailed information on using the Claude Code Setup tool effectively, including common use cases and examples.

## Command Overview

Claude Code Setup offers the following main commands:

- `init`: Initialize Claude Code setup in your project or globally
- `list`: Display available templates and current settings
- `add`: Add templates or settings to your configuration
- `update`: Update templates or settings to their latest versions
- `remove`: Remove templates or settings from your configuration

Each command supports both interactive and direct usage modes to accommodate different user preferences.

## Working with Templates

Templates are pre-defined command configurations stored as Markdown files that enhance your Claude Code experience.

### Listing Available Templates

To see what templates are available:

```bash
# Interactive list with options to add/update
claude-setup list

# Non-interactive list of just templates
claude-setup list templates
```

The output shows templates organized by category, with indicators for which ones you already have installed.

### Adding Templates

Templates can be added in two ways:

#### Interactive Template Selection

```bash
# Launch interactive template selection
claude-setup add
# Then choose "Templates" from the menu and select the ones you want
```

This approach presents a categorized list of templates with checkboxes to select multiple templates at once.

#### Direct Template Installation

```bash
# Install a specific template directly
claude-setup add template code-review

# Install with force overwrite of existing template
claude-setup add template fix-issue --force

# Install to global configuration
claude-setup add template create-tasks --global
```

### Updating Templates

To ensure your templates are up to date:

```bash
# Update all installed templates
claude-setup update templates

# Update a specific template
claude-setup update code-review

# Interactive update menu
claude-setup update
```

### Using Templates

After installation, templates are available in your Claude Code environment. You can use them by:

1. Running Claude Code with the template name
2. Accessing them through the Claude Code interface
3. Referencing them in Claude Code command flags

## Managing Settings

Settings control how Claude Code behaves and what permissions it has.

### Viewing Current Settings

```bash
# List current settings
claude-setup list settings
```

This shows your current theme, permissions, and environment variables.

### Adding Settings

#### Adding Permissions

Permissions control what tools Claude Code can use:

```bash
# Add a specific Bash permission
claude-setup add permission "Bash(npm:*)"

# Add Python permissions
claude-setup add permission "Python(*)"

# Interactive permission addition
claude-setup add
# Then select "Permission" and follow the prompts
```

#### Setting Themes

Choose between available UI themes:

```bash
# Set the dark theme
claude-setup add theme dark

# Set the default theme
claude-setup add theme default

# Interactive theme selection
claude-setup add
# Then select "Theme" from the menu
```

#### Adding Environment Variables

Configure environment variables for Claude Code:

```bash
# Set an environment variable
claude-setup add env NODE_ENV production

# Interactive environment variable addition
claude-setup add
# Then select "Environment Variable" and follow the prompts
```

### Updating Settings

To update your settings to the latest defaults while preserving your customizations:

```bash
# Update all settings
claude-setup update settings
```

## Advanced Usage

### Local vs Global Configuration

Claude Code Setup supports both project-level and global configurations:

```bash
# Initialize in current project
claude-setup init

# Initialize globally
claude-setup init --global

# Add template to global config
claude-setup add template code-review --global
```

The global configuration is stored in `~/.claude` and is available for all your projects.

### Testing Mode

When developing templates or configurations, you can use test mode:

```bash
# Initialize in a test directory
claude-setup init --test-dir ./my-test-dir

# Test adding a template
claude-setup add template code-review --test-dir ./my-test-dir
```

This creates a contained environment for testing without affecting your actual configuration.

### Dry Run Mode

To see what changes would be made without actually making them:

```bash
# Dry run initialization
claude-setup init --dry-run

# Dry run template addition
claude-setup add template code-review --dry-run
```

### Command Templates by Category

Claude Code Setup organizes templates into these categories:

1. **General** - Broadly applicable templates like code reviews and issue fixing
   - Example: `code-review`, `fix-issue`

2. **Node** - Templates specific to Node.js development
   - Example: `node-optimization`

3. **Python** - Templates specific to Python development
   - Example: `python-optimization`

4. **Project** - Templates for project management tasks
   - Example: `create-tasks`, `generate-docs`, `update-tasks`

## Example Workflows

### Setting Up a New Project

```bash
# Initialize locally with interactive prompts
claude-setup init

# Add common templates
claude-setup add template code-review
claude-setup add template fix-issue
claude-setup add template create-tasks

# Configure environment
claude-setup add theme dark
claude-setup add env NODE_ENV development
```

### Updating an Existing Setup

```bash
# List what's currently installed
claude-setup list

# Update all templates
claude-setup update templates

# Update settings to latest defaults
claude-setup update settings
```

### Customizing for Different Projects

```bash
# Python project setup
claude-setup init
claude-setup add template python-optimization
claude-setup add permission "Python(*)"

# Node.js project setup
claude-setup init
claude-setup add template node-optimization
claude-setup add permission "Bash(npm:*)"
```

## Troubleshooting Common Issues

### Missing Templates

If templates are not appearing in the list:

```bash
# Check current setup location
claude-setup list

# Ensure you're viewing the correct location
claude-setup list --global  # for global templates
```

### Permission Issues

If Claude Code can't perform certain actions:

```bash
# Add necessary permissions
claude-setup add permission "Bash(your-command:*)"

# List current permissions to verify
claude-setup list settings
```

### Configuration Conflicts

If you encounter configuration conflicts:

```bash
# Force overwrite existing settings
claude-setup init --force

# Or update existing settings
claude-setup update settings
```

## Integrating with Existing Workflows

Claude Code Setup can be incorporated into your development workflow:

- Include it in your project setup scripts
- Add template installation to your CI/CD pipeline for consistent team usage
- Create custom templates for your specific project needs

By understanding these commands and examples, you can make the most of Claude Code Setup to enhance your development experience.