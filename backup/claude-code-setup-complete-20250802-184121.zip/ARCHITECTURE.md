# Claude Code Setup Architecture

This document describes the architectural design of the Claude Code Setup tool, explaining its components, their relationships, and how data flows through the system.

## System Overview

Claude Code Setup is organized as a modular CLI application with a clean separation of concerns between command definition, business logic, and utility functions. The architecture follows a command-based pattern using Commander.js as its foundation, with specialized modules handling different aspects of the application's functionality.

```mermaid
graph TD
    A[Entry Point: bin.js] --> B[Main: src/index.ts]
    B --> C[Commands]
    C --> C1[init.ts]
    C --> C2[main.ts]
    C1 --> U[Utils]
    C2 --> U
    U --> U1[fs.ts]
    U --> U2[logger.ts]
    U --> U3[settings.ts]
    U --> U4[template.ts]
    U --> U5[ui.ts]
    T[Templates] --> T1[general/]
    T --> T2[node/]
    T --> T3[project/]
    T --> T4[python/]
    S[Settings] --> S1[defaults.json]
    S --> S2[permissions/]
    S --> S3[themes/]
```

## Core Components

### Command Structure

The application uses a hierarchical command structure:

1. **Entry Point**: `bin.js` launches the application and delegates to the compiled code
2. **Main Module**: `src/index.ts` defines the root Commander program and registers commands
3. **Command Modules**: Specialized modules implement specific command functionality
   - `init.ts`: Handles initialization of the Claude Code configuration
   - `main.ts`: Contains unified commands for add, list, update, and remove operations

Each command follows a consistent pattern:
- Definition with Commander.js
- Options with descriptive help text
- Action handlers that implement the command logic
- Interactive and non-interactive modes for flexibility

### Template Management

Templates are stored as Markdown files organized by category:

1. **Template Registry**: In-memory cache of all available templates
2. **Template Loading**: Dynamic loading from the filesystem
3. **Template Operations**: Add, list, update, and remove functionality
4. **Category Organization**: Templates grouped by purpose (general, node, project, python)

Templates flow through the system as follows:
1. Files are read from the templates directory at runtime
2. Loaded into the template registry via `getAllTemplates()`
3. Presented to users via the list command
4. Installed to the user's `.claude/commands/` directory when added
5. Updated when newer versions are available

### Settings Management

Settings are stored as JSON files with a hierarchical structure:

1. **Default Settings**: Base settings providing standard configuration
2. **User Settings**: Customizations stored in `.claude/settings.json`
3. **Merged Settings**: Runtime combination of defaults and user settings

The settings system handles:
- Permission sets for tool access
- UI themes (default, dark)
- Environment variables
- Settings validation using Zod schema validation

### File System Operations

The file system layer abstracts disk operations:

1. **Directory Management**: Creating, validating, and managing the `.claude` directory structure
2. **Template I/O**: Reading and writing template files
3. **Settings I/O**: Reading and writing settings files
4. **Path Resolution**: Handling global vs. local paths

```mermaid
flowchart TD
    User[User] --> CLI[CLI Commands]
    CLI --> Templates[Template Management]
    CLI --> Settings[Settings Management]
    Templates --> FS[File System Operations]
    Settings --> FS
    FS --> DiskT[Template Files]
    FS --> DiskS[Settings Files]
```

## Data Flow

The typical data flow for commands follows this pattern:

1. **Command Invocation**: User runs a command with options
2. **Path Resolution**: System determines whether to use local or global directories
3. **Data Loading**: Existing templates or settings are loaded if needed
4. **Command Processing**: The specific operation is performed
5. **Feedback**: Results are displayed to the user with appropriate formatting

For interactive commands, the flow includes additional steps:
1. **User Prompts**: System presents options via inquirer.js
2. **Selection Processing**: User choices are validated and processed
3. **Multi-step Interaction**: For complex operations like initialization

## Key Design Patterns

1. **Command Pattern**: Each CLI command is encapsulated in its own module
2. **Registry Pattern**: Templates are stored in a registry for easy lookup
3. **Factory Pattern**: Settings are created and merged dynamically
4. **Adapter Pattern**: Different file operations are abstracted behind a common interface
5. **Strategy Pattern**: Different modes (interactive vs. direct) for command execution

## Error Handling

Error handling follows a consistent approach throughout the application:
1. Commands use try/catch blocks to capture errors
2. Error messages are logged with the logger utility
3. User-friendly error messages are displayed with appropriate formatting
4. Process exits with non-zero codes for command-line error reporting

This architecture ensures a maintainable, extensible system that can grow with additional features while maintaining a consistent user experience.